package bufferedimg;
//imports
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.EmptyStackException;
import java.util.Scanner;

public class BufferedImg {
    //atributos de uso general
    private Scanner entrada = new Scanner(System.in);
    private String datos = entrada.nextLine();
    private BufferedImage originalImage = null;
    
    //método que lee la imagen
    public void leerImagen() throws IOException{
        try {
            originalImage = ImageIO.read(new File(datos));
        } catch (IOException e) {
            throw new EmptyStackException();
        }       
    }
    
    //método para convertir la imagen a escala de grises
    public void convertirGrises(){
        for (int x = 0; x < originalImage.getWidth(); x++){
            for(int y = 0; y < originalImage.getHeight(); y++){
                Color pixelColor = new Color(originalImage.getRGB(x, y));
                int red = pixelColor.getRed();
                int green = pixelColor.getGreen();
                int blue = pixelColor.getBlue();
                int mediaRGB = (red + green + blue) / 3;
                int mediaRGBInteger = (mediaRGB << 16) | (mediaRGB << 8) | mediaRGB;
                originalImage.setRGB(x, y, mediaRGBInteger);
            }
        }
    } 
    
    //crea una copia de la imagen en escala de grises
    public void creaImagen(){
        try {
            ImageIO.write(originalImage, "jpg", new File("imagenGRIS.jpg"));
            } 
        catch (IOException e) { 
            e.printStackTrace(); 
        }
        System.out.println("Creada la nueva imagen en gris -> imagenGRIS.jpg.");
    }
    
    //datos imagen
    public void getDatos(){
        Raster dimensiones = originalImage.getData();
        System.out.println(dimensiones);
    }

    public static void main(String[] args) throws IOException {
        System.out.println("introduce imagen (Ejemplo: imagen.jpg)");
        BufferedImg obj = new BufferedImg();
        obj.leerImagen();
        obj.convertirGrises();
        obj.creaImagen();
        
    }
}
